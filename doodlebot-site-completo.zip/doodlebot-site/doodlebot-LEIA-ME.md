# Doodle Bot — site com chat

Arquivos:
- `doodlebot-index.js`: seu bot com a ponte do site
- `doodlebot-web.js`: servidor do site (ponte)
- `public/doodlebot-site.html`: o site
- `public/doodlebot-icone*` e `doodlebot-manifest.webmanifest`: ícone do app

O site conversa com o **mesmo código do seu bot**: cada mensagem digitada no site entra no `doodlebot-index.js` como se fosse um chat privado do WhatsApp. Por isso todos os comandos funcionam de verdade (economia, IA, `!tocar`, `!fig`...), e o saldo, itens e nível ficam no mesmo `dados.json`.

## Instalar (30 segundos)
Na pasta do bot:
1. Coloque na pasta do bot (junto da pasta `assets/` e do `sessao/`) os arquivos `doodlebot-index.js` e `doodlebot-web.js` e a pasta `public/`.
2. Rode: `node doodlebot-index.js`  (é o seu `index.js` já com a ponte; se preferir manter o nome antigo, renomeie ele de volta para `index.js`, mas o `doodlebot-web.js` e a pasta `public/` precisam continuar com esses nomes).
3. Pode apagar o `index.js` antigo depois de conferir que está tudo certo. O `dados.json` e a sessão do WhatsApp continuam os mesmos.

Não precisa instalar nada novo. Vai aparecer: `Site do Doodle Bot no ar: http://localhost:3000`

## Abrir
- No próprio celular (Termux): abra `http://localhost:3000` no Chrome. Menu do Chrome > "Adicionar à tela inicial" vira um app.
- Na mesma rede wi-fi: o endereço `http://IP:3000` aparece no terminal.
- Pra qualquer pessoa, com link https: `pkg install cloudflared` e depois `cloudflared tunnel --url http://localhost:3000`. Ele mostra um link `https://...trycloudflare.com`.
- Porta ocupada? `WEB_PORT=3001 node doodlebot-index.js`

Site hospedado em outro lugar (GitHub Pages etc.)? No `public/doodlebot-site.html`, antes do `<script>` principal, coloque `<script>window.DOODLE_API='https://SEU-LINK-DO-TUNEL'</script>`.

## O que o site faz
- Abertura "play doodle bot", depois "qual o seu nome", depois o chat.
- Todos os comandos que funcionam no privado. Digite `!` pra ver a lista, ou toque no `!` ao lado do campo.
- Figurinha, `!img` e `!revelar`: anexe uma foto (clipe) com `!fig` na legenda, ou segure/deslize uma mídia pra direita, toque em responder e mande o comando. Dá pra marcar "visualização única" pra testar o `!revelar`.
- Comandos que só existem em grupo (ranking, casar, banir, pix...) respondem que só funcionam no WhatsApp.
- Cada navegador tem um código de acesso (menu ⋮ > Meu código). Guarde ele pra não perder saldo e itens.

## O que mudou no seu index.js (agora doodlebot-index.js)
- Ponte com o site (3 trechos curtos, procure por `ponteWeb`).
- No site, mesada diária, contagem de mensagens e nível funcionam como num grupo.
- Correção: `!inventario`, `!perfil` e `!doar` liam o inventário numa chave diferente da que o `!comprar` grava, então o inventário aparecia sempre vazio (no WhatsApp também). Agora usam a mesma.
- Correção de segurança: `!tocar` e `!baixar` montavam comando de terminal com o texto da pessoa, então algo como `$(comando)` rodava no seu celular. Agora esses caracteres são removidos. Importante com o site aberto pra internet.
- O site limita mensagens por minuto e pedidos pesados (`!tocar`, `!baixar`, `!criarimg`, `!voz`) ao mesmo tempo.
